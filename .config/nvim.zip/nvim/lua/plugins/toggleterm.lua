return {
  { "akinsho/toggleterm.nvim", version = "*", config = true },
}
