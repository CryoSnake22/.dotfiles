return {
  { "dccsillag/magma-nvim", build = ":UpdateRemotePlugins" },
}
